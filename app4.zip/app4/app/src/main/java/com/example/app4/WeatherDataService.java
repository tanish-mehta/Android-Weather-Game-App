package com.example.app4;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class WeatherDataService {

    // API url
    public static final String CITY_ID_URL="https://www.metaweather.com/api/location/search/?query=";
    public static final String CITY_WEATHER_URL = "https://www.metaweather.com/api/location/";

    Context context;
    String cityID;

    // consructor
    public WeatherDataService(Context context) {
        this.context = context;
    }

    public interface VolleyResponseListener {
        void onError(String message);
        void onResponse(String cityID);
    }

    // method to find the id of a city from the city name
    public void getCityID(String cityName, VolleyResponseListener volleyResponseListener){
        String url =CITY_ID_URL+cityName;

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET,url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                cityID="";
                try {
                    JSONObject cityData= response.getJSONObject(0);
                    cityID=cityData.getString("woeid");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                volleyResponseListener.onResponse(cityID);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                volleyResponseListener.onError("ERROR");

            }
        });
        MySingleton.getInstance(context).addToRequestQueue(request);
    }

    // method to find the city weather by using the city id
    public void getCityForecastByID(String cityID, ForeCastByIDResponse foreCastByIDResponse) {
        List<WeatherReportModel> weatherReportModels = new ArrayList<>();

        String url = CITY_WEATHER_URL + cityID;
        // get the json object
        JsonObjectRequest request = new JsonObjectRequest (Request.Method. GET, url,null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray consolidated_weather_list = response.getJSONArray("consolidated_weather");
                    for(int i=0; i<consolidated_weather_list.length();i++) {
                        WeatherReportModel one_day_weather = new WeatherReportModel();
                        JSONObject first_day_from_api = (JSONObject) consolidated_weather_list.get(i);
                        one_day_weather.setId(first_day_from_api.getInt("id"));
                        one_day_weather.setWeather_state_name(first_day_from_api.getString("weather_state_name"));
                        one_day_weather.setWeather_state_abbr(first_day_from_api.getString("weather_state_abbr"));
                        one_day_weather.setApplicable_date(first_day_from_api.getString("applicable_date"));
                        one_day_weather.setMin_temp(first_day_from_api.getLong("min_temp"));
                        one_day_weather.setMax_temp(first_day_from_api.getLong("max_temp"));
                        one_day_weather.setThe_temp(first_day_from_api.getLong("the_temp"));
                        one_day_weather.setWind_speed(first_day_from_api.getLong("wind_speed"));
                        weatherReportModels.add(one_day_weather);
                    }
                    foreCastByIDResponse.onResponse(weatherReportModels);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        MySingleton.getInstance(context).addToRequestQueue(request);
    }

    public interface ForeCastByIDResponse{
        void onError(String message);

        void onResponse(List<WeatherReportModel> weatherReportModels);
    }

    public interface GetCityForecastByNameCallback {
        void onError(String message);
        void onResponse(List<WeatherReportModel> weatherReportModels);
    }

    //method to get the city weather by using the city name
    public void getCityByForecastName(String cityName, GetCityForecastByNameCallback getCityForecastByNameCallback){
        getCityID(cityName, new VolleyResponseListener() {
            @Override
            public void onError(String message) {

            }
            @Override
            public void onResponse(String cityID) {
                getCityForecastByID(cityID, new ForeCastByIDResponse() {
                    @Override
                    public void onError(String message) {}
                    @Override
                    public void onResponse(List<WeatherReportModel> weatherReportModels) {
                        getCityForecastByNameCallback.onResponse(weatherReportModels);
                    }
                });
            }
        });
    }

    // method to get only the current weather using city name
    public void getCurrentWeather(String cityName,GetCurrentTempCallback getCurrentTempCallback){
        getCityID(cityName, new VolleyResponseListener(){
            @Override
            public void onError(String message) {
            }

            @Override
            public void onResponse(String cityID) {
                getCityTemp(cityID, new GetCurrentTempCallback() {
                    @Override
                    public void onError(String message) {}
                    @Override
                    public void onResponse(String temp) {
                        getCurrentTempCallback.onResponse(temp);
                    }
                });
            }
        });
    }

    public interface GetCurrentTempCallback{
        void onError(String message);
        void onResponse(String temp);
    }

    //method to get the current city temperature using city name
    public void getCityTemp(String cityID, GetCurrentTempCallback getCurrentTempCallback) {
        String url = CITY_WEATHER_URL + cityID;
        // get the json object
        JsonObjectRequest request = new JsonObjectRequest (Request.Method. GET, url,null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray consolidated_weather_list = response.getJSONArray("consolidated_weather");
                    JSONObject first_day_from_api = (JSONObject) consolidated_weather_list.get(0);
                    float temp= first_day_from_api.getLong("the_temp");
                    String finalTemp=String.valueOf((int)temp);
                    getCurrentTempCallback.onResponse(finalTemp);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        MySingleton.getInstance(context).addToRequestQueue(request);
    }

}
