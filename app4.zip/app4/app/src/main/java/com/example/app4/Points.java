package com.example.app4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class Points extends AppCompatActivity {

    private TextView text_view_points;
    private Button btn_reset_points;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_points);
        Context context=Points.this;
        SharedPreferences prefs = context.getSharedPreferences("counters", Context.MODE_PRIVATE);
        text_view_points= (TextView) findViewById(R.id.text_view_points);
        btn_reset_points= (Button) findViewById(R.id.btn_reset_points);

        // shared preferences value for points displayed
        String pointsText="Points Collected= "+ prefs.getInt("counter", 0);
        text_view_points.setText(pointsText);

        // resetting points value so user can start new game
        btn_reset_points.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int counter = prefs.getInt("counter", 0); // Using '0' for the default value
                prefs.edit().putInt("counter", 0).apply();
                String pointsText="Points Collected= "+ prefs.getInt("counter", 0);
                text_view_points.setText(pointsText);
            }
        });
    }
}