package com.example.app4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;


import java.util.ArrayList;
import java.util.List;

public class Weather extends AppCompatActivity {

    private EditText enter_city;
    private Button submit_city;
    private TextView large_temp;
    private TextView idTVCondition;
    private ImageView imgMain;

    private RecyclerView recycler;
    private WeatherRVAdapter mExampleAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);
        enter_city = findViewById(R.id.enter_city);
        submit_city = findViewById(R.id.submit_city);
        large_temp = findViewById(R.id.large_temp);
        idTVCondition = findViewById(R.id.idTVCondition);
        imgMain=(ImageView)findViewById(R.id.main_image);

        // creating recycler view
        recycler = findViewById(R.id.recycler);
        recycler.setHasFixedSize(true);
        recycler.setLayoutManager(new LinearLayoutManager(Weather.this));

        final WeatherDataService weatherDataService= new WeatherDataService(Weather.this);

        submit_city.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // setting the weather image as a link to open google search about city weather
                imgMain.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent link=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=weather "+enter_city.getText()));
                        startActivity(link);
                    }
                });

                // fetching city weather
                weatherDataService.getCityByForecastName(enter_city.getText().toString(), new WeatherDataService.GetCityForecastByNameCallback() {
                    @Override
                    public void onError(String message) {
                        Toast.makeText( Weather.this,"something wrong", Toast.LENGTH_SHORT).show();
                    }
                    @Override
                    public void onResponse (List<WeatherReportModel> weatherReportModels) {

                        //setting value of large condition and temperature display
                        idTVCondition.setText(weatherReportModels.get(0).getWeather_state_name());
                        large_temp.setText(String.valueOf((int) weatherReportModels.get(0).getThe_temp()));

                        // passing data list to recycler view adapter
                        mExampleAdapter = new WeatherRVAdapter(Weather.this, weatherReportModels);
                        recycler.setAdapter(mExampleAdapter);

                        // using picasso library to display weather image
                        String imageUrl="https://www.metaweather.com/static/img/weather/png/"+weatherReportModels.get(0).getWeather_state_abbr()+".png";
                        Picasso.get().load(imageUrl).into(imgMain);
                    }
                });
            }
        });
    }
}