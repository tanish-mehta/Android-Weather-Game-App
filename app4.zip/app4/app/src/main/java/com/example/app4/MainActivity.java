package com.example.app4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;


import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private Button play_btn;
    private Button weather_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // when the 'play' or 'weather' buttons get clicked, they should open the respective activties
        play_btn = (Button) findViewById(R.id.play_button);
        weather_btn = (Button) findViewById(R.id.weather_button);

        play_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openPlayGame();
            }
        });

        weather_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openWeather();
            }
        });
    }

    private void openPlayGame(){
        Intent intent= new Intent(this, PlayGame.class);
        startActivity(intent);
    }
    private void openWeather(){
        Intent intent= new Intent(this, Weather.class);
        startActivity(intent);
    }

    // creating a menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // launching activities when menu item is clicked
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.optn_contact:
                Intent intentContact= new Intent(this, Contact.class);
                startActivity(intentContact);
                return true;
            case R.id.optn_points:
                Intent intentPoints= new Intent(this, Points.class);
                startActivity(intentPoints);
                return true;
            case R.id.optn_about:
                Intent intentTutorial= new Intent(this, About.class);
                startActivity(intentTutorial);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}