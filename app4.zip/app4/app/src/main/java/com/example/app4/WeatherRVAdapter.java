package com.example.app4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

// recycler view adpater
public class WeatherRVAdapter extends RecyclerView.Adapter<WeatherRVAdapter.weatherrvViewHolder> {

    public Context mContext;
    private List<WeatherReportModel> exampleList;

    public WeatherRVAdapter(Context mContext, List<WeatherReportModel> exampleList) {
        this.mContext = mContext;
        this.exampleList = exampleList;
    }

    @NonNull
    //@org.jetbrains.annotations.NotNull
    @Override
    public weatherrvViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(mContext).inflate(R.layout.weather_rv_layout,parent,false);
        return new weatherrvViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull weatherrvViewHolder holder, int position) {
        WeatherReportModel currentItem=exampleList.get(position);
        String imageUrl="https://www.metaweather.com/static/img/weather/png/"+currentItem.getWeather_state_abbr()+".png";
        String date= "Date: "+ currentItem.getApplicable_date();
        String state= "State: "+ currentItem.getWeather_state_name();
        String max= "Max: "+ String.valueOf((int)currentItem.getMax_temp());
        String min= "Min: "+ String.valueOf((int)currentItem.getMin_temp());
        String wind= "Wind: "+ String.valueOf((int)currentItem.getWind_speed());


        holder.date.setText(date);
        holder.max.setText(max);
        holder.min.setText(min);
        holder.state.setText(state);
        holder.wind.setText(wind);
        Picasso.get().setLoggingEnabled(true);
        Picasso.get().load(imageUrl).resize(100,100).into(holder.image);
    }

    @Override
    public int getItemCount() {
        return exampleList.size();
    }

    public class weatherrvViewHolder extends RecyclerView.ViewHolder {
        public ImageView image;
        public TextView date;
        public TextView min;
        public TextView max;
        public TextView wind;
        public TextView state;

        public weatherrvViewHolder(@NonNull View itemView) {
            super(itemView);
            image=itemView.findViewById(R.id.weather_icon);
            date=itemView.findViewById(R.id.date);
            state=itemView.findViewById(R.id.state);
            min=itemView.findViewById(R.id.min);
            max=itemView.findViewById(R.id.max);
            wind=itemView.findViewById(R.id.wind);
        }
    }
}
