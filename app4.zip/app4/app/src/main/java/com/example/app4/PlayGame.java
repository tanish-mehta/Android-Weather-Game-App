package com.example.app4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class PlayGame extends AppCompatActivity {

    private final String[] CITY_LIST = {"Birmingham","Blackpool","Bournemouth","Bradford","Brighton",
            "Bristol","Cambridge","Coventry","Derby","Exeter","Falmouth","Huddersfield","Ipswich",
            "Kingston upon Hull","Leeds","Leicester","Lisbon","Liverpool","London","Luton",
            "Manchester","Ajaccio","Bordeaux","Calvi","Lille","Lyon","Marseille","Nice","Paris",
            "Toulouse","Ahmedabad","Bangalore","Chennai","Hyderabad","Kolkata","Mumbai","New Delhi",
            "Pune","Surat","Beijing","Chengdu","Dongguan","Guangzhou","Hangzhou","Hong Kong",
            "Shanghai","Shenzhen","Tianjin","Riyadh",};

    private Random r;
    private TextView city_name;
    private EditText guess;
    private Button submit;
    private Button btn_getAnswer;
    private Button newCity;
    int randomNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_game);

        final WeatherDataService weatherDataService= new WeatherDataService(PlayGame.this);

        city_name = (TextView) findViewById(R.id.city_name);
        newCity=(Button) findViewById(R.id.new_city);
        submit=(Button) findViewById(R.id.submit);
        guess=(EditText) findViewById(R.id.answer);
        btn_getAnswer=(Button) findViewById(R.id.getAnswer);
        newCity.setOnClickListener(new View.OnClickListener() {

            // picking random city from list and displaying it
            @Override
            public void onClick(View view) {
                r = new Random();
                randomNumber = r.nextInt(CITY_LIST.length);
                city_name.setText(CITY_LIST[randomNumber]);
            }
        });

        Context context= PlayGame.this;
        SharedPreferences preferences = context.getSharedPreferences("counters", Context.MODE_PRIVATE);

        // fetching correct answer from API and checking if submitted answer is correct
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                weatherDataService.getCurrentWeather(city_name.getText().toString(), new WeatherDataService.GetCurrentTempCallback() {
                    @Override
                    public void onError(String message) {
                        Toast.makeText( PlayGame.this,"something wrong", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onResponse(String temp) {
                        if(temp.equals(guess.getText().toString())){
                            //Using shared preferences to count points
                            int counter = preferences.getInt("counter", 0);
                            preferences.edit().putInt("counter", ++counter).apply();
                            Toast.makeText( PlayGame.this,"Correct! Points="+counter, Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText( PlayGame.this,"Sorry. Your answer is wrong", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });

        // if the user wants to know the asnwer
        btn_getAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                weatherDataService.getCurrentWeather(city_name.getText().toString(), new WeatherDataService.GetCurrentTempCallback() {
                    @Override
                    public void onError(String message) {
                        Toast.makeText( PlayGame.this,"ERROR", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onResponse(String temp) {
                        Toast.makeText( PlayGame.this,"The answer is "+ temp, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        // if user clicks on city name, a google search will open of the city
        city_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent link=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q= "+city_name.getText()));
                startActivity(link);
            }
        });
    }
}

